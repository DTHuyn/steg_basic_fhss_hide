import numpy as np
from scipy.io import wavfile
import random
import os

# Kiểm tra file đầu vào
if not os.path.exists("original_audio.wav"):
    print("Lỗi: File original_audio.wav không tồn tại.")
    exit(1)
if not os.path.exists("binary_message.txt"):
    print("Lỗi: File binary_message.txt không tồn tại. Vui lòng chạy text_to_binary.py trước.")
    exit(1)

# Đọc file âm thanh
sample_rate, audio = wavfile.read("original_audio.wav")
audio = audio.astype(np.float32)

# Đọc file nhị phân
with open("binary_message.txt", "r") as f:
    binary_message = f.read()

# Tham số FHSS
frame_size = 1024
hop_size = 512
freq_range = np.linspace(1000, 2000, 100)
random.seed(42)
freq_sequence = random.sample(list(freq_range), len(freq_range))

# Hàm nhúng bit vào một frame
def embed_bit(frame, bit, freq, sample_rate):
    fft_data = np.fft.fft(frame)
    freq_bins = np.fft.fftfreq(len(frame), 1/sample_rate)
    freq_idx = np.argmin(np.abs(freq_bins - freq))
    
    # Nhúng bit: tăng/giảm biên độ
    if bit == "1":
        fft_data[freq_idx] *= 5.0  # Tăng mạnh hơn cho bit 1
    else:
        fft_data[freq_idx] *= 0.05  # Giảm mạnh hơn cho bit 0
    
    modified_frame = np.fft.ifft(fft_data).real
    return modified_frame

# Chia âm thanh thành các frame và nhúng tin
output_audio = np.copy(audio)
bit_idx = 0
for i in range(0, len(audio) - frame_size, hop_size):
    if bit_idx >= len(binary_message):
        break
    frame = audio[i:i+frame_size]
    bit = binary_message[bit_idx]
    freq = freq_sequence[bit_idx % len(freq_sequence)]
    modified_frame = embed_bit(frame, bit, freq, sample_rate)
    output_audio[i:i+frame_size] = modified_frame
    bit_idx += 1

# Báo cáo số bit đã nhúng
#print(f"Đã nhúng {bit_idx} bit vào âm thanh.")

# Lưu file âm thanh mà không chuẩn hóa mạnh
output_audio = output_audio.astype(np.int16)
wavfile.write("stego_audio.wav", sample_rate, output_audio)

print("Đã tạo file stego_audio.wav")