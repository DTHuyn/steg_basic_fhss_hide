# Đọc file message.txt
with open("message.txt", "r", encoding="utf-8") as f:
    message = f.read().strip()

# Chuyển message sang nhị phân
binary_message = ""
for char in message:
    # Chuyển ký tự sang ASCII, rồi sang nhị phân 8-bit
    ascii_val = ord(char)
    binary_char = format(ascii_val, "08b")  # Đảm bảo 8 bit
    binary_message += binary_char

# Lưu vào file binary_message.txt
with open("binary_message.txt", "w") as f:
    f.write(binary_message)
print("Tin cần giấu là: "+message+" chuyển sang mã nhị phân là: "+binary_message)
print("Đã tạo file binary_message.txt")
